'use strict';
/* ===== Helpers & configuration ===== */
const $ = (s, r = document) => r.querySelector(s);
const KEY = 'nepaliCV.v1';
const DECL = 'I hereby declare that the information provided above is true and correct to the best of my knowledge and belief.';
const LV = ['Basic', 'Intermediate', 'Good', 'Advanced', 'Expert'];
const RT = ['Excellent', 'Very Good', 'Good', 'Average', 'Basic'];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const T = v => String(v ?? '').trim();
const F = (k, l, ph = '', x = {}) => ({ k, l, ph, ...x });
const PXMM = (() => { const d = document.createElement('div'); d.style.cssText = 'position:absolute;visibility:hidden;width:100mm'; document.body.appendChild(d); const w = d.offsetWidth / 100; d.remove(); return w; })();

const PF = [
  F('name', 'Full Name', 'Enter your full name', { wide: 1 }),
  F('title', 'Professional Title', 'e.g. Civil Engineer', { wide: 1 }),
  F('email', 'Email', 'name@example.com', { type: 'email' }),
  F('phone', 'Mobile Number', 'Enter mobile number', { type: 'tel' }),
  F('phone2', 'Alternative Phone Number', 'Optional', { type: 'tel' }),
  F('web', 'Portfolio / Website', 'yourwebsite.com'),
  F('addr', 'Current Address', 'Area, City, District', { wide: 1 }),
  F('paddr', 'Permanent Address', 'Municipality-Ward, District, Province', { wide: 1 }),
  F('dob', 'Date of Birth', 'e.g. 2058/05/20'),
  F('gender', 'Gender', '', { o: ['Male', 'Female', 'Other'] }),
  F('nat', 'Nationality', 'e.g. Nepali'),
  F('marital', 'Marital Status', '', { o: ['Unmarried', 'Married', 'Divorced', 'Widowed'] }),
  F('cit', 'Citizenship Number', 'Enter citizenship number'),
  F('citd', 'Citizenship Issued District', 'e.g. Kaski'),
  F('father', "Father's Name", "Enter father's name"),
  F('mother', "Mother's Name", "Enter mother's name"),
  F('blood', 'Blood Group', '', { o: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] }),
  F('religion', 'Religion', 'e.g. Hindu'),
  F('linkedin', 'LinkedIn', 'linkedin.com/in/username', { wide: 1 })
];

const LISTS = {
  edu: { t: 'Education', item: 'Education', add: '+ Add Education', f: [F('level', 'Level', 'e.g. Bachelor, +2, SEE'), F('inst', 'Institution', 'School / College name'), F('board', 'Board / University', 'e.g. Tribhuvan University'), F('year', 'Passed Year', 'e.g. 2080'), F('gpa', 'GPA / Division', 'e.g. 3.6 or First Division')] },
  train: { t: 'Training', item: 'Training', add: '+ Add Training', f: [F('name', 'Training / Course', 'Course name', { wide: 1 }), F('inst', 'Institute', 'Institute name'), F('dur', 'Duration', 'e.g. 3 months'), F('year', 'Year', 'e.g. 2079')] },
  exp: { t: 'Work Experience', item: 'Experience', add: '+ Add Experience', f: [F('org', 'Organization', 'Company / organization'), F('pos', 'Position', 'Your job title'), F('loc', 'Location', 'City, District'), F('start', 'Start Date', 'e.g. 2078/04'), F('end', 'End Date', 'Leave blank if current'), F('resp', 'Responsibilities (one bullet per line)', 'Managed daily site reports\nPrepared cost estimates', { area: 1, wide: 1, rows: 5 })] },
  tech: { t: 'Technical Skills', item: 'Skill', add: '+ Add Skill', f: [F('name', 'Skill Name', 'e.g. MS Excel'), F('level', 'Skill Level', '', { o: LV })] },
  key: { t: 'Key Skills', item: 'Key skill', add: '+ Add Skill', f: [F('v', 'Key Skill', 'e.g. Communication')] },
  lang: { t: 'Languages', item: 'Language', add: '+ Add Language', f: [F('l', 'Language', 'e.g. Nepali'), F('s', 'Speaking', '', { o: RT }), F('r', 'Reading', '', { o: RT }), F('w', 'Writing', '', { o: RT })] },
  proj: { t: 'Projects', item: 'Project', add: '+ Add Project', f: [F('title', 'Project Title', 'Project name', { wide: 1 }), F('org', 'Organization / College', 'Where it was done'), F('dur', 'Duration', 'e.g. 6 months'), F('desc', 'Description (one bullet per line)', 'What you built or achieved', { area: 1, wide: 1 })] },
  intern: { t: 'Internship', item: 'Internship', add: '+ Add Internship', f: [F('org', 'Organization', 'Company / organization'), F('pos', 'Position / Department', 'e.g. IT Department'), F('dur', 'Duration', 'e.g. 2 months'), F('work', 'Major Work (one bullet per line)', 'Tasks you handled', { area: 1, wide: 1 })] },
  cert: { t: 'Achievements', item: 'Certificate', add: '+ Add Certificate', f: [F('name', 'Certificate / Achievement', 'Certificate name', { wide: 1 }), F('org', 'Issuing Organization', 'Issued by'), F('year', 'Year', 'e.g. 2080')] },
  strength: { t: 'Strengths', item: 'Strength', add: '+ Add Strength', f: [F('v', 'Personal Strength', 'e.g. Quick Learner')] },
  hobby: { t: 'Hobbies', item: 'Hobby', add: '+ Add Hobby', f: [F('v', 'Hobby / Interest', 'e.g. Reading')] },
  ref: { t: 'References', item: 'Reference', add: '+ Add Reference', f: [F('name', 'Name', 'Referee name'), F('pos', 'Position', 'Referee position'), F('org', 'Organization', 'Organization'), F('contact', 'Contact', 'Phone number'), F('email', 'Email', 'referee@example.com', { wide: 1 })] }
};

const blank = () => ({ p: {}, obj: '', fresher: false, refsReq: false, decl: DECL, sig: { place: '', date: '', name: '' }, photo: '', signImg: '', lists: Object.fromEntries(Object.keys(LISTS).map(k => [k, [{}]])) });
let data = blank();

/* ===== Form builder ===== */
let uid = 0;
function fld(f, attrs, val = '') {
  const id = 'f' + (++uid), a = `id="${id}" name="${f.k}" ${attrs}`;
  const c = f.o
    ? `<select ${a}><option value="">Select</option>${f.o.map(o => `<option${o === val ? ' selected' : ''}>${o}</option>`).join('')}</select>`
    : f.area
      ? `<textarea ${a} rows="${f.rows || 3}" placeholder="${esc(f.ph)}">${esc(val)}</textarea>`
      : `<input ${a} type="${f.type || 'text'}" value="${esc(val)}" placeholder="${esc(f.ph)}">`;
  return `<div class="fld${f.wide ? ' wide' : ''}"><label for="${id}">${f.l}</label>${c}<small class="err" aria-live="polite"></small></div>`;
}
const chk = (g, l, v) => `<label class="chk"><input type="checkbox" data-g="${g}"${v ? ' checked' : ''}> ${l}</label>`;
const det = (t, body, open) => `<details class="card"${open ? ' open' : ''}><summary>${t}</summary><div class="body">${body}</div></details>`;
const listSec = (n, extra = '') => det(LISTS[n].t, `${extra}<div id="list-${n}"></div><button type="button" class="btn add" data-add="${n}">${LISTS[n].add}</button>`);
const upload = (id, rm, label, img, alt, cls) => `<div class="photo"><img id="${img}" class="${cls}" alt="${alt}" hidden><div><label for="${id}">${label}</label><input type="file" id="${id}" accept=".jpg,.jpeg,.png,image/jpeg,image/png"><button type="button" class="btn sm" id="${rm}">Remove</button></div></div>`;

function buildForm() {
  $('#form').innerHTML =
    det('Personal Information', upload('photoIn', 'photoRm', 'Passport-size photo (JPG, JPEG, PNG)', 'photoPrev', 'Photo preview', 'thumb') + `<div class="grid2">${PF.map(f => fld(f, `data-p="${f.k}"`, data.p[f.k])).join('')}</div>`, 1) +
    det('Career Objective', fld(F('obj', 'Career Objective', 'Write a short professional objective…', { area: 1, rows: 6 }), 'data-g="obj"', data.obj), 1) +
    listSec('edu') + listSec('train') +
    listSec('exp', chk('fresher', 'I am a fresher (no work experience)', data.fresher)) +
    listSec('tech') + listSec('key') + listSec('lang') + listSec('proj') + listSec('intern') + listSec('cert') + listSec('strength') + listSec('hobby') +
    listSec('ref', chk('refsReq', 'References available upon request', data.refsReq)) +
    det('Declaration & Signature',
      fld(F('decl', 'Declaration', '', { area: 1, rows: 3 }), 'data-g="decl"', data.decl) +
      `<div class="grid2">${fld(F('place', 'Place', 'e.g. Kathmandu'), 'data-g="sig.place"', data.sig.place)}${fld(F('date', 'Date', 'e.g. 2083/06/15'), 'data-g="sig.date"', data.sig.date)}${fld(F('sname', 'Name', 'Name under signature', { wide: 1 }), 'data-g="sig.name"', data.sig.name)}</div>` +
      upload('signIn', 'signRm', 'Signature image (optional)', 'signPrev', 'Signature preview', 'thumb sig-t'));
  Object.keys(LISTS).forEach(renderList);
  imgUI();
}

function renderList(n) {
  const c = LISTS[n];
  $('#list-' + n).innerHTML = data.lists[n].map((o, i) => {
    const at = k => `data-list="${n}" data-i="${i}" data-k="${k}"`;
    const del = `<button type="button" class="btn del" data-del="${n}" data-i="${i}" aria-label="Delete ${c.item} ${i + 1}">Delete</button>`;
    return c.f.length === 1
      ? `<div class="row1">${fld(c.f[0], at(c.f[0].k), o[c.f[0].k])}${del}</div>`
      : `<div class="entry"><div class="eh"><span>${c.item} ${i + 1}</span>${del}</div><div class="grid2">${c.f.map(f => fld(f, at(f.k), o[f.k])).join('')}</div></div>`;
  }).join('');
}

function imgUI() {
  [['photoPrev', 'photo'], ['signPrev', 'signImg']].forEach(([id, k]) => {
    const im = $('#' + id); if (!im) return;
    im.hidden = !data[k];
    data[k] ? im.src = data[k] : im.removeAttribute('src');
  });
}

/* ===== Validation ===== */
function validate(t) {
  const k = t.dataset.p, v = T(t.value), d = v.replace(/[\s-]/g, '');
  let m = '';
  if (k === 'email' && v && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) m = 'Enter a valid email, e.g. name@example.com';
  if ((k === 'phone' || k === 'phone2') && v && !(/^(\+?977)?9[6-8]\d{8}$/.test(d) || /^(\+?977)?0?\d{1,2}\d{6,7}$/.test(d))) m = 'Enter a valid Nepali number, e.g. 98XXXXXXXX or 01-4XXXXXX';
  t.classList.toggle('invalid', !!m);
  t.setAttribute('aria-invalid', !!m);
  const e = t.parentElement.querySelector('.err'); if (e) e.textContent = m;
}

/* ===== Form events (delegated) ===== */
const formEl = $('#form');
function onField(e) {
  const t = e.target, d = t.dataset, v = t.type === 'checkbox' ? t.checked : t.value;
  if (d.p) { data.p[d.p] = v; validate(t); }
  else if (d.list) data.lists[d.list][+d.i][d.k] = v;
  else if (d.g) { const [a, b] = d.g.split('.'); b ? data[a][b] = v : data[a] = v; }
  else return;
  updateCV();
}
formEl.addEventListener('input', onField);
formEl.addEventListener('change', e => {
  if (e.target.id === 'photoIn') handlePhotoUpload(e.target, 'photo');
  else if (e.target.id === 'signIn') handlePhotoUpload(e.target, 'signImg');
  else onField(e);
});
formEl.addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  const d = b.dataset;
  if (d.add) { data.lists[d.add].push({}); renderList(d.add); $('#list-' + d.add).lastElementChild.querySelector('input,select,textarea').focus(); }
  else if (d.del) { data.lists[d.del].splice(+d.i, 1); renderList(d.del); }
  else if (b.id === 'photoRm') { data.photo = ''; imgUI(); }
  else if (b.id === 'signRm') { data.signImg = ''; imgUI(); }
  else return;
  updateCV();
});

/* ===== Photo / signature upload (browser only) ===== */
function handlePhotoUpload(input, key) {
  const file = input.files && input.files[0]; if (!file) return;
  if (!/^image\/(jpe?g|png)$/.test(file.type)) { toast('Please choose a JPG, JPEG or PNG image.', 'err'); input.value = ''; return; }
  const fr = new FileReader();
  fr.onload = () => {
    const im = new Image();
    im.onload = () => {
      const max = key === 'photo' ? 600 : 500, s = Math.min(1, max / Math.max(im.width, im.height));
      const c = document.createElement('canvas'); c.width = Math.round(im.width * s); c.height = Math.round(im.height * s);
      const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0, c.width, c.height);
      data[key] = c.toDataURL('image/jpeg', .88); imgUI(); updateCV();
    };
    im.onerror = () => toast('Could not read that image.', 'err');
    im.src = fr.result;
  };
  fr.readAsDataURL(file);
  input.value = '';
}

/* ===== CV content builders (each returns an array of page blocks) ===== */
const rows = n => data.lists[n].filter(o => Object.values(o).some(v => T(v)));
const chunk = (a, n) => a.reduce((r, x, i) => (i % n ? r[r.length - 1].push(x) : r.push([x]), r), []);
const section = (title, items, head = '') => items.map((h, i) => `<div class="blk${i ? '' : ' sf'}">${i ? '' : `<h2>${title}</h2>${head}`}${h}</div>`);
const kv = (l, v, c = '') => `<div class="kv ${c}"><b>${l}</b><span>${esc(v)}</span></div>`;
const cell = v => esc(T(v)) || '–';
const dates = (s, e) => { s = T(s); e = T(e); return s && e ? `${s} – ${e}` : s ? `${s} – Present` : e; };
const bul = t => { const a = T(t).split(/\n+/).map(x => x.replace(/^\s*[-•*]\s*/, '').trim()).filter(Boolean); return a.length ? `<ul>${a.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : ''; };
const desc = t => { const a = T(t).split(/\n+/).filter(x => x.trim()); return a.length > 1 ? bul(t) : a.length ? `<p class="just">${esc(a[0])}</p>` : ''; };
const item = (a, r, s, b) => { a = T(a); s = T(s); if (!a) { a = s; s = ''; } return `<div class="it"><div class="r2"><b>${esc(a)}</b><span class="dt">${esc(r)}</span></div>${s ? `<div class="sub">${esc(s)}</div>` : ''}${b || ''}</div>`; };

function table(title, n, cols, heads, keys) {
  const r = rows(n); if (!r.length) return [];
  const st = `style="grid-template-columns:${cols}"`;
  return section(title, r.map(o => `<div class="tr" ${st}>${keys.map(k => `<span>${cell(o[k])}</span>`).join('')}</div>`), `<div class="tr th" ${st}>${heads.map(h => `<span>${h}</span>`).join('')}</div>`);
}

function updateHeader() {
  const p = data.p, n = T(p.name);
  const c = [['Email', p.email], ['Mobile', [p.phone, p.phone2].map(T).filter(Boolean).join(' / ')], ['Address', p.addr], ['LinkedIn', p.linkedin], ['Website', p.web]].filter(([, v]) => T(v));
  return [`<div class="blk hd"><div class="hd-l"><h1${n ? '' : ' class="ph"'}>${esc(n || 'Your Full Name')}</h1>${T(p.title) ? `<div class="ttl">${esc(p.title)}</div>` : ''}${c.map(([l, v]) => kv(l, v)).join('')}</div>${data.photo ? `<div class="hd-p"><img src="${data.photo}" alt="Passport-size photo of ${esc(n || 'the applicant')}"></div>` : ''}</div>`];
}

const updateObjective = () => T(data.obj) ? section('Career Objective', [`<p class="just">${esc(T(data.obj))}</p>`]) : [];

function updatePersonalInfo() {
  const p = data.p;
  const L = [['dob', 'Date of Birth'], ['gender', 'Gender'], ['nat', 'Nationality'], ['marital', 'Marital Status'], ['father', "Father's Name"], ['mother', "Mother's Name"], ['cit', 'Citizenship No.'], ['citd', 'Issued District'], ['blood', 'Blood Group'], ['religion', 'Religion']];
  const items = L.filter(([k]) => T(p[k])).map(([k, l]) => kv(l, p[k]));
  if (T(p.paddr)) items.push(kv('Permanent Address', p.paddr, 'full'));
  return items.length ? section('Personal Profile', [`<div class="pg">${items.join('')}</div>`]) : [];
}

const updateEducation = () => table('Educational Qualification', 'edu', '27mm 1fr 38mm 14mm 24mm', ['Level', 'Institution', 'Board / University', 'Year', 'GPA / Division'], ['level', 'inst', 'board', 'year', 'gpa']);
const updateTraining = () => table('Professional / Technical Training', 'train', '1fr 50mm 30mm 16mm', ['Training / Course', 'Institute', 'Duration', 'Year'], ['name', 'inst', 'dur', 'year']);
const updateCertificates = () => table('Achievements & Certifications', 'cert', '1fr 60mm 16mm', ['Certificate / Achievement', 'Issuing Organization', 'Year'], ['name', 'org', 'year']);
const updateLanguages = () => table('Language Proficiency', 'lang', '1fr 32mm 32mm 32mm', ['Language', 'Speaking', 'Reading', 'Writing'], ['l', 's', 'r', 'w']);

function updateExperience() {
  const r = rows('exp');
  if (!r.length) return data.fresher ? section('Work Experience', ['<p class="note">Fresher</p>']) : [];
  return section('Work Experience', r.map(o => {
    const pos = T(o.pos);
    return item(pos || o.org, dates(o.start, o.end), pos ? [o.org, o.loc].map(T).filter(Boolean).join(', ') : o.loc, bul(o.resp));
  }));
}
const updateInternship = () => section('Internship', rows('intern').map(o => item(o.org, o.dur, o.pos, bul(o.work))));
const updateProjects = () => section('Projects', rows('proj').map(o => item(o.title, o.dur, o.org, desc(o.desc))));

const tags = (title, n) => section(title, chunk(rows(n).map(o => T(o.v)).filter(Boolean), 12).map(c => `<ul class="cols">${c.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`));
function updateSkills() {
  const t = rows('tech').filter(o => T(o.name));
  const sk = o => { const n = LV.indexOf(o.level) + 1; return `<div class="sk"><span>${esc(T(o.name))}</span>${n ? `<span class="lv"><i class="pp">${'●'.repeat(n)}${'○'.repeat(5 - n)}</i> ${o.level}</span>` : ''}</div>`; };
  return [...section('Computer / Technical Skills', chunk(t, 10).map(c => `<div class="skg">${c.map(sk).join('')}</div>`)), ...tags('Key Skills', 'key')];
}

function updateReferences() {
  if (data.refsReq) return section('References', ['<p>References available upon request.</p>']);
  return section('References', chunk(rows('ref'), 4).map(c => `<div class="refs">${c.map(o => {
    const ln = [T(o.name) && `<b>${esc(T(o.name))}</b>`, [o.pos, o.org].map(T).filter(Boolean).map(esc).join(', '), T(o.contact) && `Contact: ${esc(T(o.contact))}`, T(o.email) && `Email: ${esc(T(o.email))}`].filter(Boolean);
    return `<div class="ref">${ln.join('<br>')}</div>`;
  }).join('')}</div>`));
}

function updateDeclaration() {
  const s = data.sig, d = T(data.decl), nm = T(s.name) || T(data.p.name);
  const has = T(s.place) || T(s.date) || T(s.name) || data.signImg;
  if (!d && !has) return [];
  const left = [['Place', s.place], ['Date', s.date]].filter(([, v]) => T(v)).map(([l, v]) => kv(l, v)).join('');
  return [`<div class="blk sf">${d ? `<h2>Declaration</h2><p class="just">${esc(d)}</p>` : ''}${has ? `<div class="sigrow"><div class="sl">${left}</div><div class="sigr">${data.signImg ? `<img src="${data.signImg}" alt="Signature">` : '<div class="gap"></div>'}<div class="sigline">${esc(nm)}</div></div></div>` : ''}</div>`];
}

/* ===== Rendering & A4 pagination ===== */
let raf;
function updateCV() { cancelAnimationFrame(raf); raf = requestAnimationFrame(render); }

function render() {
  const blocks = [
    ...updateHeader(), ...updateObjective(), ...updatePersonalInfo(), ...updateEducation(), ...updateTraining(),
    ...updateExperience(), ...updateInternship(), ...updateProjects(), ...updateSkills(), ...updateLanguages(),
    ...updateCertificates(), ...tags('Personal Strengths', 'strength'), ...tags('Hobbies & Interests', 'hobby'),
    ...updateReferences(), ...updateDeclaration()
  ];
  const m = $('#measure');
  m.innerHTML = blocks.join('');
  const hs = [...m.children].map(c => c.getBoundingClientRect().height);
  m.innerHTML = '';
  const cap = (296.5 - 14 - 16 - 1.5) * PXMM;
  const pages = [[]]; let used = 0;
  blocks.forEach((b, i) => {
    if (used + hs[i] > cap && pages[pages.length - 1].length) { pages.push([]); used = 0; }
    pages[pages.length - 1].push(b); used += hs[i];
  });
  $('#pages').innerHTML = pages.map((p, i) => `<section class="page" aria-label="CV page ${i + 1}"><div class="pc cv">${p.join('')}</div>${pages.length > 1 ? `<div class="pn">Page ${i + 1} of ${pages.length}</div>` : ''}</section>`).join('');
}

/* ===== Zoom (screen only) ===== */
let zoom = 1, manual = false;
function setZoom(z, m) {
  zoom = Math.min(1.5, Math.max(.4, z)); manual = manual || !!m;
  $('#pages').style.zoom = zoom; $('#zval').textContent = Math.round(zoom * 100) + '%';
}
function fitZoom() { if (!manual) setZoom(Math.min(1, ($('.preview-panel').clientWidth - 24) / (210 * PXMM))); }

/* ===== Storage ===== */
function merge(o) {
  const b = blank(); o = o || {};
  const r = { ...b, ...o, p: { ...b.p, ...o.p }, sig: { ...b.sig, ...o.sig }, lists: { ...b.lists, ...o.lists } };
  Object.keys(LISTS).forEach(k => { if (!Array.isArray(r.lists[k])) r.lists[k] = [{}]; });
  return r;
}
function setData(o) { data = merge(o); buildForm(); updateCV(); }
function saveData() {
  try { localStorage.setItem(KEY, JSON.stringify(data)); toast('CV data saved in this browser.'); }
  catch (e) { toast('Could not save (storage full or blocked). Try a smaller photo.', 'err'); }
}
function loadData(silent) {
  let raw = null; try { raw = localStorage.getItem(KEY); } catch (e) { /* storage blocked */ }
  if (!raw) { if (!silent) toast('No saved CV found.', 'err'); return false; }
  try { setData(JSON.parse(raw)); if (!silent) toast('Saved CV loaded.'); return true; }
  catch (e) { toast('Saved data is damaged.', 'err'); return false; }
}
function clearData() {
  if (!confirm('Clear the form and delete the saved CV from this browser?')) return;
  try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
  setData(blank()); toast('All data cleared.');
}
function loadSample() {
  setData({
    p: { name: 'Ram Sharma', title: 'Civil Engineer', email: 'ram.sharma@example.com', phone: '9841234567', addr: 'Baneshwor, Kathmandu', paddr: 'Pokhara-10, Kaski, Gandaki Province', dob: '2058/05/20', gender: 'Male', nat: 'Nepali', marital: 'Unmarried', father: 'Hari Sharma', mother: 'Sita Sharma', cit: '27-01-75-01234', citd: 'Kaski', blood: 'O+', religion: 'Hindu' },
    obj: 'To work as a Civil Engineer in a reputed organization where I can apply my technical knowledge, grow professionally and contribute to the success of the company.',
    lists: {
      edu: [{ level: 'Bachelor in Civil Engineering', inst: 'Pulchowk Campus', board: 'Tribhuvan University', year: '2080', gpa: '3.7' }, { level: '+2 Science', inst: 'Budhanilkantha School', board: 'NEB', year: '2075', gpa: '3.6' }, { level: 'SEE', inst: 'Shree Secondary School', board: 'NEB', year: '2073', gpa: '3.8' }],
      train: [{ name: 'AutoCAD & Revit Training', inst: 'CAD Institute', dur: '3 months', year: '2080' }],
      exp: [{ org: 'Himalayan Construction Pvt. Ltd.', pos: 'Site Engineer', loc: 'Kathmandu', start: '2080/06', end: '', resp: 'Supervised daily construction activities\nPrepared quantity estimates and bills\nCoordinated with contractors and clients' }, { org: 'Nepal Infra Solutions', pos: 'Junior Engineer', loc: 'Lalitpur', start: '2079/01', end: '2080/05', resp: 'Assisted in survey and design works\nMaintained site records' }],
      intern: [{ org: 'Department of Roads', pos: 'Design Section', dur: '2 months', work: 'Assisted in road alignment design\nPrepared drawings using AutoCAD' }],
      proj: [{ title: 'Design of a Three-Storey RCC Building', org: 'Pulchowk Campus', dur: '6 months', desc: 'Analysed and designed the structure using ETABS and IS/NBC codes.' }],
      tech: [{ name: 'MS Word', level: 'Advanced' }, { name: 'MS Excel', level: 'Advanced' }, { name: 'AutoCAD', level: 'Good' }, { name: 'ETABS', level: 'Intermediate' }],
      key: [{ v: 'Communication' }, { v: 'Teamwork' }, { v: 'Problem Solving' }, { v: 'Time Management' }],
      lang: [{ l: 'Nepali', s: 'Excellent', r: 'Excellent', w: 'Excellent' }, { l: 'English', s: 'Good', r: 'Good', w: 'Good' }, { l: 'Hindi', s: 'Good', r: 'Good', w: 'Average' }],
      cert: [{ name: 'Engineering Council Registration', org: 'Nepal Engineering Council', year: '2081' }],
      strength: [{ v: 'Hardworking' }, { v: 'Quick Learner' }, { v: 'Punctual' }],
      hobby: [{ v: 'Reading' }, { v: 'Travelling' }, { v: 'Photography' }],
      ref: [{ name: 'Er. Bishnu Adhikari', pos: 'Project Manager', org: 'Himalayan Construction', contact: '9851234567', email: 'bishnu@example.com' }]
    },
    sig: { place: 'Kathmandu', date: '2083/06/15', name: '' }
  });
}

/* ===== Print ===== */
function printCV() {
  if (!T(data.p.name)) {
    const d = $('#form details'); d.open = true;
    const i = $('[data-p="name"]'); i.classList.add('invalid');
    i.parentElement.querySelector('.err').textContent = 'Full Name is required to generate the CV.';
    i.scrollIntoView({ block: 'center' }); i.focus();
    toast('Please enter your Full Name first.', 'err'); return;
  }
  render(); window.print();
}

/* ===== Toast ===== */
let tt;
function toast(m, type) {
  const t = $('#toast'); t.textContent = m; t.className = 'show ' + (type || '');
  clearTimeout(tt); tt = setTimeout(() => { t.className = ''; }, 3200);
}

/* ===== Init ===== */
$('#btnSave').addEventListener('click', saveData);
$('#btnLoad').addEventListener('click', () => loadData(false));
$('#btnClear').addEventListener('click', clearData);
$('#btnSample').addEventListener('click', loadSample);
$('#btnPrint').addEventListener('click', printCV);
$('#btnPdf').addEventListener('click', printCV);
$('#zin').addEventListener('click', () => setZoom(zoom + .1, true));
$('#zout').addEventListener('click', () => setZoom(zoom - .1, true));
window.addEventListener('resize', fitZoom);
if (!loadData(true)) setData(blank());
fitZoom();
